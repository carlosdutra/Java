import javax.swing.*;
import java.awt.*;

public class ShowBorderLayout extends JFrame {
	
	public ShowBorderLayout() {
	
	setLayout(new BorderLayout(5, 10));
	add(new JButton("EAST"), BorderLayout.EAST);
	add(new JButton("SOUTH"), BorderLayout.SOUTH);
	add(new JButton("WEST"), BorderLayout.WEST);
	add(new JButton("NORTH"), BorderLayout.NORTH);
	add(new JButton("CENTER"), BorderLayout.CENTER);
	
	}

	public static void main(String[] args) {
	
		ShowBorderLayout frame = new ShowBorderLayout();
		frame.setTitle("Show Border Layout");
		frame.setSize(200, 150);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}
}
