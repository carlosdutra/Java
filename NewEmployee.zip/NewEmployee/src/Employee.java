import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Employee {
	
	private String name;
	private String address;
	private String date;
	private String hiredDate;
	public int salary;
		
	
	public void setDate(String date) {
		this.date = date;
	}	
	public String getDate() {
		return date;
	}
	/////////////////////////
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	////////////////////////
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	////////////////////////
	public void setHiredDate(String hiredDate) {
		this.hiredDate = hiredDate;
	}
	public String getHiredDate() {
		return hiredDate;
	}
	////////////////////////
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getSalary() {
		return salary;
	}
	
	//
	
	public Employee()
	{
		
		
	}
	
	public Employee(String name)
	{
		this.name = name;		
	}
	
	//
	
	
	
}
