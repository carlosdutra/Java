import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;


public class Driver {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);		
		Employee newEmployee = new Employee();
		
						
		System.out.println("Please enter employee name:");
		newEmployee.setName(input.nextLine());
		
		System.out.println("Please enter employee address:");
		newEmployee.setAddress(input.nextLine());
		
		System.out.println("Please enter employee date of birth(MM/DD/YYYY):");
		newEmployee.setDate(input.nextLine());		
		
		
		System.out.println("Please enter when the employee was hired(MM/DD/YYYY):");
		newEmployee.setHiredDate(input.nextLine());
		
		System.out.println("Please enter employee year salary:");
		newEmployee.setSalary(input.nextInt());
				
		
		
		System.out.println("The data for the new employee as entered:");
		System.out.println("Name: " + newEmployee.getName());
		System.out.println("Address: " + newEmployee.getAddress());
		System.out.println("DOB: " + newEmployee.getDate());		
		System.out.println("Salary: " + newEmployee.getSalary());

	}
	
	

}
